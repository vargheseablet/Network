<!DOCTYPE html>
<html class="full" lang="en">
<head>
  <title>Network Banking</title>
  <meta charset="utf-8">
   <meta http-equip="X-UA-Compatable" content="IE-edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link href="http://localhost/NetworkBanking/media/css/login.css" rel="stylesheet">
  <script src="http://localhost/NetworkBanking/media/js/my_js.js"></script>


  <style>
    /* Remove the navbar's default margin-bottom and rounded borders */ 
    .navbar {
      margin-bottom: 0;
      border-radius: 0;
    }

   
    
    /* Add a gray background color and some padding to the footer */
    footer {
      background-color: #f2f2f2;
      padding: 25px;
    }
    
  .carousel-inner img {
      width: 100%; /* Set width to 100% */
      margin: auto;
      min-height:200px;
  }

  /* Hide the carousel text when the screen is less than 600 pixels wide */
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Profile</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li></li>
         <li>
       
        <a href="#" onclick="div_create_show()"><span class="glyphicon glyphicon-user-add"></span>Create Account</a></li> 

        <li>
        <!-- <button id="lpopup"  onclick="div_show()"><span class="glyphicon glyphicon-log-in"></span> Login</button> -->
        <a href="#" onclick="div_loginLink_show()"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> 
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators" >
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="http://www.pixelstalk.net/wp-content/uploads/2016/03/Dark-background-free-download.jpg" alt="Image" style="width:100%;
          max-height: 200px !important;">
        <div class="carousel-caption">
          <h3>Network Banking!</h3>
          <p>Create multiple accounts and perform basic bank transactions on one click!</p>
        </div>      
      </div>

      <div class="item">
       
        <img src="http://hdwallpaperia.com/wp-content/uploads/2013/11/Dark-Background-Wallpaper.jpg" alt="Image" style="width:100%;
          max-height: 200px !important;">
        <div class="carousel-caption">
          
          <h3>Facilities!</h3>
          <p>-Widraw! -Diposit! -Transfer!</p>
        </div>      
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>
  



<div class="container text-center">    
  <h3>Click on one of the Bank and Get started! :D</h3><br>
  <div class="row">
    <div class="col-sm-4">
      <img src="http://www.pixelstalk.net/wp-content/uploads/2016/03/Dark-background-free-download.jpg" class="img-responsive" style="width:100%" alt="Image">
      <p>Bank 1</p>
    </div>
    <div class="col-sm-4"> 
      <img src="http://www.pixelstalk.net/wp-content/uploads/2016/03/Dark-background-free-download.jpg" class="img-responsive" style="width:100%" alt="Image">
      <p>Bank 2</p>    
    </div>
   <div class="col-sm-4"> 
      <img src="http://www.pixelstalk.net/wp-content/uploads/2016/03/Dark-background-free-download.jpg" class="img-responsive" style="width:100%" alt="Image">
      <p>Bank 3</p>    
    </div>
  </div>
</div><br>


<div id="loginLink">
    <!-- Popup Div Starts Here -->
    <div id="popupContact">
      <!-- Contact Us Form -->
      <form name="myForm" action="<?php echo base_url()?>Bank/authenticate" method="POST" ;">
        <img id="close" src="file:///C:/xampp/htdocs/NetworkBanking/media/images/3.png" width=22px height=22px onclick ="div_loginLink_hide()">
        <h2> Login</h2>
        <hr>
        <table style="width:100%"  cellpadding="10" >
        <tr>
        <td><label style="margin-top: 20px">Email</label></td>
        <td><input name="email" type="text" placeholder="Email" size="" id="email" /></td>
        </tr>
        <tr>      
        <td><label style="margin-bottom: 30px">Password    </label></td>
        <td><input name="psw" type="password" placeholder="Password" id="password" /></td>
        </tr>
        <tr>
        <td colspan="2">
        <input type="submit" value="Login" id="submit"/></td>
        </tr>
        <tr><td></td></tr>
        </table>
      </form>      
    </div>
    <!-- Popup Div Ends Here -->
</div>





<div id="create">
        <!-- Popup Div Starts Here -->
    <div id="popupContact">
      <!-- Contact Us Form -->

      <!-- Form Starts here -->

      <form name="create_form" method="POST" action="<?php echo base_url()?>Bank/insert_db" onsubmit="return(Submit())">    <!-- Form Description -->
           <img id="close" src="file:///C:/xampp/htdocs/NetworkBanking/media/images/3.png" width=22px height=22px onclick ="div_create_hide()">
        <label>Username</label>
        <br />
        <input type="text" name="uname">
        <br />

        <label>Email</label>
        <br />
        <input type="email" name="email">
        <br />

        <label>Mobile Number(Enter a mobile number that is linked to atleast one of the banks)</label>
        <br />
        <input type="text" name="mob_no" maxlength="10">
        <br />

        <label>Password</label>
        <br />
        <input type="password" name="psw">
        <br /><br />

        <input type="submit" value="Sign Up">
      </form>

      <!-- Form ends here -->
        </div>
    <!-- Popup Div Ends Here -->


    </div>


<footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>

</body>
</html>
